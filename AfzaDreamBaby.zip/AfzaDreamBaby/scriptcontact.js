
//   ------------------contact.html--------------

const about = document.querySelector("#contactaddress");
const map = document.querySelector("#contactmap");
const contact = document.querySelector("#contactform");
const contactAddress = document.querySelector("#contact-address");
const contactMap = document.querySelector("#contact-map");
const contactForm = document.querySelector("#contact-form");

about.addEventListener("click", () => {
  const aboutBox = new WinBox({
    title: "Address",
    width: "650px",
    height: "350px",
    top: 150,
    right: 50,
    bottom: 50,
    left: 50,
    mount: contactAddress,
    onfocus: function () {
      this.setBackground("blue");
    },
    onblur: function () {
      this.setBackground("#777");
    },
  });
});

map.addEventListener("click", () => {
  const mapBox = new WinBox({
    title: "Map",
    //modal: true,
    width: "650px",
    height: "500px",
    top: 150,
    right: 50,
    bottom: 50,
    left: 50,
    mount: contactMap,
    onfocus: function () {
      this.setBackground("blue");
    },
    onblur: function () {
      this.setBackground("#777");
    },
  });
});

contact.addEventListener("click", () => {
  const contactBox = new WinBox({
    title: "Contact Us",
    width: "800px",
    height: "750px",
    top: 100,
    right: 10,
    bottom: 50,
    left: 150,
    mount: contactForm,
    onfocus: function () {
      this.setBackground("blue");
    },
    onblur: function () {
      this.setBackground("#777");
    },
  });
});

  